#!/bin/bash
pwd
mongod --config ./conf/mongod.conf
