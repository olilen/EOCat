#!/bin/bash

curl -H "Authorization: Basic b2Jhcm9pczpCYXJjZWxvbmExIQ==" 'https://scihub.copernicus.eu/dhus/api/stub/products?filter=(%20ingestionDate:[2016-11-01T00:00:00.000Z%20TO%202016-11-15T23:59:59.999Z%20]%20)&offset=0&limit=25&sortedby=beginposition&order=desc'

#Set-Cookie	JSESSIONID=F2C19FD15F4056D801BFC8D646499157; Path=/api/stub/; HttpOnly

#Authorization	Basic b2Jhcm9pczpCYXJjZWxvbmExIQ==
