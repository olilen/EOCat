#!/bin/bash
curl  'http://localhost:3000/harvestOADS?dataset=IKONOS&url=https%3A%2F%2Foads-tpm2.evo-pdgs.com%2Foads%2Fmeta%2FIKONOS2%2Findex%2F'
