#!/bin/bash
curl  'http://localhost:3000/harvestOADS?url=https%3A%2F%2Fesar-ds.eo.esa.int%2Foads%2Fmeta%2FASA_IMS_1P%2Findex%2F'
