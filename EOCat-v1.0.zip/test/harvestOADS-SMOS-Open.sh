#!/bin/bash
curl  'http://localhost:3000/harvestOADS?dataset=SMOS-Open&url=https%3A%2F%2Fsmos-ds-02.eo.esa.int%2Foads%2Fmeta%2FSMOS_Open%2Findex%2F%0A'

