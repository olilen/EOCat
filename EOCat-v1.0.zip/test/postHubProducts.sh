#!/bin/bash
curl -H "Content-Type: application/json" -vX POST --data @scihubResultSet.json http://localhost:3000/hubProducts/
