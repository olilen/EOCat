#!/bin/bash
curl  'http://localhost:3000/harvestOADS?url=https%3A%2F%2Falos-palsar-ds.eo.esa.int%2Foads%2Fmeta%2FALOS_PALSAR_WB1_RAW%2Findex%2F'
