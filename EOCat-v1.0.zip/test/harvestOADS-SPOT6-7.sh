#!/bin/bash
curl  'http://localhost:3000/harvestOADS?dataset=SPOT6-7&url=https%3A%2F%2Foads-tpm2.evo-pdgs.com%2Foads%2Fmeta%2FSPOT6-7%2Findex%2F%0A'