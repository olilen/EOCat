#!/bin/bash
curl  'http://localhost:3000/harvestOADS?dataset=IKONOS&url=https%3A%2F%2Foads-tpm2.evo-pdgs.com%2Foads%2Fmeta%2FIKONOS2%2Findex%2F'
curl  'http://localhost:3000/harvestOADS?dataset=Pleiades&url=https%3A%2F%2Foads-tpm2.evo-pdgs.com%2Foads%2Fmeta%2FPleiades%2Findex%2F'
curl  'http://localhost:3000/harvestOADS?dataset=SPOT6-7&url=https%3A%2F%2Foads-tpm2.evo-pdgs.com%2Foads%2Fmeta%2FSPOT6-7%2Findex%2F%0A'
curl  'http://localhost:3000/harvestOADS?dataset=SMOS-Open&url=https%3A%2F%2Fsmos-ds-02.eo.esa.int%2Foads%2Fmeta%2FSMOS_Open%2Findex%2F%0A'

