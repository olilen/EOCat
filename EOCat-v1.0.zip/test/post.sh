#!/bin/bash
curl -H "Content-Type: application/json" -vX POST --data @testProduct.json http://localhost:3000/products?dataset=testDataset
