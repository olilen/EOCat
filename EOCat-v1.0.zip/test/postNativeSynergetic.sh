#!/bin/bash
curl -H "Content-Type: application/json" -vX POST --data @testProductSynergetic.json http://localhost:3000/products?dataset=testDataset
